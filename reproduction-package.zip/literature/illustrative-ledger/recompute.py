"""Recompute the constructed illustration; this is not experiment analysis."""
from pathlib import Path
import csv,json
p=Path(__file__).resolve().parent
alloc=list(csv.DictReader((p/'allocations.csv').open()))
outcomes=list(csv.DictReader((p/'outcomes.csv').open()))
fees=json.loads((p/'fees.json').read_text())
result={}
for policy in ['Cold','Warm','Suspend']:
 rows=[r for r in alloc if r['policy']==policy]
 cpu=sum((float(r['end_s'])-float(r['start_s']))*float(r['allocated_cpu']) for r in rows)
 mem=sum((float(r['end_s'])-float(r['start_s']))*float(r['allocated_gib']) for r in rows)
 money=sum((float(r['end_s'])-float(r['start_s']))*float(r['allocated_cpu'])*float(r['dollars_per_cpu_second']) for r in rows)+sum(r['dollars'] for r in fees if r['policy']==policy)
 statuses={s:sum(r['policy']==policy and r['status_at_t1']==s for r in outcomes) for s in ['valid','failed','pending_censored']}
 valid=statuses['valid']
 result[policy]={'counts':statuses,'CPU_s':cpu,'GiB_s':mem,'dollars':money,'G_CPU':valid/cpu,'G_mem':valid/mem,'G_dollars':valid/money}
expected=json.loads((p/'SUMMARY.json').read_text())['summary']
for policy in result:
 for field in ['CPU_s','GiB_s','dollars','G_CPU','G_mem','G_dollars']:
  assert abs(result[policy][field]-expected[policy][field])<1e-8,(policy,field)
print(json.dumps(result,indent=2))
