# Human source checks — 1 completed, 31 pending

H1 completed a guided source check of RT-02: the original figure, stated method, numerical ratio and configuration scope were confirmed, and the requested scope qualification was applied to the manuscript. H1 is a pseudonym for the human participant in the research session; a real name is not inferred or included in this anonymous record. The other31selected assertions remain pending. Existing32record model-assisted checks remain a separate historical layer. No human inter-rater agreement or independent experimental reproduction is claimed. AUTHOR_VERIFICATION_32.csv is the current row-level status; human_source_checks/CURRENT.json preserves the scoped follow-up summary.

- RT-02 (M1): 2607.01415v1, §3 lines282–298; §4.2 lines315–330; Fig2 PDF p3, saved page-3.png visually checked — **human H1 checked; requested scope qualification applied (2026-11-17)**
- RT-03 (M1): 2607.01415v1, §3 lines282–298; §4.2 lines315–330; Fig2 PDF p3, saved page-3.png visually checked — **pending human check**
- RT-05 (M1): 2607.01415v1, §4.4 lines348–399,Eq2/Table2; §6 lines416–419 — **pending human check**
- S6 (M2): 2610.39711v2, §5.4 lines502–525; AppendixE lines1458–1501;TableA11 — **pending human check**
- D1 (M3): 2609.22978v1, §2.4 lines323–328;§4 lines421–482 — **pending human check**
- D5 (M3): 2609.22978v1, §8.4 lines747–755;Fig12 — **pending human check**
- D12 (M3): 2609.22978v1, §8 opening lines709–710 — **pending human check**
- D16 (M3): 2609.22978v1, §8.1 lines711–725 — **pending human check**
- GKE-Q1 (M4): report2026-09-29;cutoff code454d3353e5c26c561dd6de389f32f7f285030e38;publication-day codebcd282caf5babf9fa877027ad34186928acfa00c, Benchmarks lines280–348;table average/max rows — **pending human check**
- GKE-WARM (M4): report2026-09-29;cutoff code454d3353e5c26c561dd6de389f32f7f285030e38;publication-day codebcd282caf5babf9fa877027ad34186928acfa00c, How we got here lines347–356;The trade-off lines417–420 — **pending human check**
- GKE-TIMER (M4): report2026-09-29;cutoff code454d3353e5c26c561dd6de389f32f7f285030e38;publication-day codebcd282caf5babf9fa877027ad34186928acfa00c, loadtest.py103–132,337–421;fleet.py1521–1537;observability.py261–285;connector-provenance.json — **pending human check**
- GKE-RESOURCE (M4): report2026-09-29;cutoff code454d3353e5c26c561dd6de389f32f7f285030e38;publication-day codebcd282caf5babf9fa877027ad34186928acfa00c, RunReport134–191;Observer261–346;recycle.py278–287 — **pending human check**
- A0 (M5): 2607.29069v2 2026-11-03, §3 lines485–513 — **pending human check**
- A1 (M5): 2607.29069v2, §4 lines518–519;§4.3 lines691–697 — **pending human check**
- A2 (M5): 2607.29069v2, §4 lines535–557 — **pending human check**
- A7 (M5): 2607.29069v2, §4.3 lines697–733;Fig9 — **pending human check**
- A8 (M5): 2607.29069v2, §4.3 lines702–745;Fig10 — **pending human check**
- AW-Q1 (M6): 2508.20404v2 2025-09-01, §3.1 lines181–193;§3.3 lines229–245;Table2 — **pending human check**
- AW-Q2 (M6): 2508.20404v2 2025-09-01, §3.1 lines181–193;§3.3 lines229–245;Table2 — **pending human check**
- AW-N1 (M6): 2508.20404v2, Body§§1–5 lines67–311;all methods/results,tables1–3,figures1–6 captions — **pending human check**
- AF-C1 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, §2.2.2–2.2.4 lines307–348;Fig3 — **pending human check**
- AF-C2 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, §4.1 lines474–487;AppendixB1591–1605;Fig5 resource_scaling_af.svg.png visually checked — **pending human check**
- AF-C3 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, §4.2 lines488–515;AppendixB1612–1671;Fig7 throughput_af.svg.png visually checked — **pending human check**
- AF-C4 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, §4.2 lines501–515;AppendixB1675–1735;Fig7 visually checked — **pending human check**
- AF-C6 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, §4.2;AppendixB Tables5–6;paper search timeout/failure/cancel/missing — **pending human check**
- AF-C7 (M7): 2507.14897v3 2026-10-09;separatecodeea275a1a284da6fd808568b8f8469a8f016516bd 2026-10-27, test_orphan_sweep_enroot.py1–191;test_engine_close.py1–79;commit-cutoff.json — **pending human check**
- E01 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, §2.1 lines273–399;Table1;officialsaa2025-page3.png visually checked — **pending human check**
- E02 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, §2.1 lines273–399;Table1;officialsaa2025-page3.png visually checked — **pending human check**
- E03 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, §2.1 lines273–399;Table1;officialsaa2025-page3.png visually checked — **pending human check**
- E05 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, §2 lines208–267;Fig1 — **pending human check**
- E06 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, §2.1 lines392–399;§3 lines407–457 — **pending human check**
- E07 (M8): 2510.05556v1;officialSAA25Table1page3 visuallycrosschecked;byteidentitynotasserted, Fullbody§§1–3 lines169–457;Table1footnotes;references inspected for tool links — **pending human check**
