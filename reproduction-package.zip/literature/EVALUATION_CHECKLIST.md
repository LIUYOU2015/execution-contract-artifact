# Agent Execution Environment Evaluation Checklist

Record an explicit value or `not reported` for each field. Attach a source/configuration locator; missing evidence is not an observed failure.

- [ ] **Evaluation identity:** task/dataset revision and instance IDs; repository base commit and patch hash; harness/evaluator/parser revisions; image digest/architecture; dependency/build inputs; cache/run identity.
- [ ] **State boundary:** files, processes, memory, credentials, external services and verifier state covered by reset/fork; intentionally shared state; unsupported domains and compensation restrictions.
- [ ] **Validity control:** repeat identical fresh-state runs; compare fresh/fresh instability with fresh/reuse differences; pin test selection, locale, seeds, services and resource constraints.
- [ ] **Operation contract:** operation, state domain, reclamation owner and transfer rule, acknowledgement point, failure model/window, requested expiry/retention deadline, evidence for an actual retention bound, and terminal postcondition. Distinguish acceptance, effect completion and reclamation.
- [ ] **Cancellation observation:** record requested/accepted/identified/ready/retained/deleted states; test reply loss and owner loss separately; verify exact ownership and unrelated sentinels through a declared horizon.
- [ ] **Evidence type:** specification, static implementation, inspected test definition, recorded execution or analytical projection; include version, configuration, denominator, trial count and limits.
- [ ] **Preparation and resources:** cold/warm cache and image state; allocation rather than utilization where appropriate; prewarming, idle/suspended holding, retries, operation fees and cleanup tail. Keep CPU-s, GiB-s and money separate.
- [ ] **Outcome ledger:** unique work identities; validity separately from task success/reward; retries, failure, timeout, cancellation, missing and administratively censored outcomes; allocation retained at the horizon.
- [ ] **Inference:** name the exact decision supported; identify unknowns that block it and those that limit portability. Do not infer cost-to-quality from acquisition latency.
- [ ] **Artifacts:** configuration/code/data hashes, commands, complete outcome/error logs, candidate selection and assertion corrections; identify archive version and public reviewer-access URL if available.

C-01 has 18 native main trials on the documented post-acceptance cancellation schedules; the three-policy ledger is a constructed accounting illustration. This checklist adapts established contract, recovery and evaluation ideas to source-linked agent execution reports.
