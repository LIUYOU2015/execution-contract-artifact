# State-domain coding decision

Coordinator adopts the source-linked15-row proposal for currentTable1. Allstate-domaincellsuseF/P/M/R/H plusdomain-local*or?. Backend/task/adaptorparametrization is retained in coding.json scope_qualifier, not mixed with physical/control domain values. Unlistedcodes are unassessed,not absent. Earlier frozen system_matrix/coarse_comparison files are historical records; thisversion supplies current Table1domaincells. No source capability or measured result was added.
