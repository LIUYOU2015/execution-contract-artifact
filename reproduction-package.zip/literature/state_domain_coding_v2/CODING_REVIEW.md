# State-domain coding review

Run: `20261116-claims-artifact-01-state-review`. Status: completed source-based proposal; coordinator adjudication pending. This is an independent model source review, not human agreement or external reproduction. All writes are confined to this directory. No native call or experiment was made; the separate 32-assertion audit was not performed here.

## Recommendation

Use one domain alphabet and retain parametrization separately. `Backend-specific`, `Task-specific`, `Bound private state`, and `Warm environment` answer different questions from F/P/M/R. They should not be peer values in the state-domain column. `H, ?` is useful when harness/trajectory state is explicit but environment scope remains delegated. The evidence supports concrete backend subsets for OpenSandbox, so its generic backend label can be replaced without inventing a universal common reset contract.

A code is positive evidence about the selected operational contract, not an exhaustive system inventory. An unlisted code is unassessed rather than absent. A star applies to the immediately preceding domain, so `F*, P*` has no cell-level ambiguity. A source-stated restriction differs from a missing empirical validation result: the latter alone does not earn a star or establish that a domain is absent.

### Code definitions

- **F:** Filesystem/file-tree state.
- **P:** Process/session state, including explicitly described browser/message-bus/shell sessions.
- **M:** Runtime/VM memory state explicitly preserved or reconstructed; memory utilization/limits alone do not qualify.
- **R:** Effects/state of external remote services explicitly covered by the operational contract; network access or remote storage of harness traces alone does not qualify.
- **H:** Explicit harness/job/rollout/trajectory state such as lifecycle status, event/trace records, or rollout-resource associations.
- **?:** Unresolved or task/backend/harness-delegated environment state scope in the selected evidence; not an absent feature.
- ***:** Domain-local marker: an explicit restriction applies to the immediately preceding domain in the selected operation/backend/contract; not an empirical correctness grade.

### Exact proposed cells

| Component | Current cell | Suggested cell | Separate scope qualifier |
|---|---|---|---|
| Sandman | F, P | **F*, P*** | Recorded baseline and selected process/session state; checked-reuse coverage is restricted. |
| DSec | F, P, M | **F, P, M** | Container/microVM persistence and pause paths; backend semantics differ. |
| CUA-Sandbox | Bound private state | **F*, P*, ?** | Task resource contract/adapters; unsupported mutable resources use private/coarser backends. |
| BunshinRL | F, P, M | **F, P, M** | Local workspace fork; external effects are outside local rollback. |
| Planarian | F, P, M, R* | **F, P, M, R*** | Local CRIU/ZFS plus supported mediated, tenant-isolated remote operations. |
| AgentFly | Backend-specific | **H, ?** | Typed resource/backend; rollout/global lifetime. |
| Aries | Backend-specific | **H, ?** | Benchmark initial state and sandbox adapter. |
| SpecBox | Warm environment | **?** | Prepared tool environment; deterministic compatible invocation cache. |
| HAL | Task-specific | **H, ?** | Benchmark/task plus local/Docker/Azure runner. |
| AgentGym-RL | Task-specific | **?** | Environment client/server and per-episode reset implementation. |
| AWorld | Task / trace | **H, ?** | Distributed task/trace state; environment payload task-dependent. |
| Agent Lightning | Harness / job | **H, ?** | Gateway rollout/event state and Job/process reconciliation; environment interaction belongs to the harness. |
| GKE RL packet | F, P; checks* | **F*, P*** | Git/tree/temp/cache reset plus process sweep and selected optional fingerprints. |
| AgentENV | F, P, M | **F, P, M** | Snapshot-backed VM starts/forks; specification and pinned implementation. |
| OpenSandbox | Backend-specific | **F*, P*, M*** | Union of explicit backend/operation subsets; no common full-state reset. |

Suggested caption text:

> Reported state domains for the selected operational contracts: F files; P processes/sessions; M runtime memory; R remote-service effects; H harness/job/trajectory state. * marks source-stated restricted coverage of the preceding domain; ? marks unresolved or task/backend/harness-delegated environment scope, not an absent feature. Codes do not imply exhaustive state coverage or validated reset/recovery.

If a second table column is too expensive, retain the qualifiers in the machine-readable evidence and define task/backend/harness delegation in the caption. The cells themselves should still contain only the common codes and markers.

## Per-row primary-source checks

### 1. Sandman — `F*, P*`

Files and persistent shell/process state are explicit. The checked-reuse baseline covers observed grader-modified state; installed files below depth two and shared memory are excluded by default, and directory modes/xattrs/ACLs are unchecked. The stars describe the selected reset/check contract, not a claim that ordinary file/process persistence is missing.

- Claims: `sandman-2610.39711:S5`. Primary locator: v2 §3.1; §4.3; Appendix H. Frozen passage: `papers/sandman-2610.39711/source.txt` lines 185–193, 253–258, 1583–1596. F/P are described; complete-state reset is not established.

### 2. DSec — `F, P, M`

File edits, installed dependencies and started services persist across calls. Container pause freezes its process tree and preserves memory through reclamation; microVM pause explicitly captures memory/execution state. This enumerates domains in selected backends, without asserting a universal reset or evaluated recovery guarantee.

- Claims: `dsec-2609.22978:D7`, `dsec-2609.22978:D11`. Primary locator: v1 §§2.3, 6.3. Frozen passage: `papers/dsec-2609.22978/source/paper-v1.txt` lines 308–320, 626–638. F/P/M are explicit in these selected lifecycle paths.

### 3. CUA-Sandbox — `F*, P*, ?`

Files/file trees, browser profiles/sessions, message-bus sessions and context-bound process state are explicit. Their sharing boundary depends on complete resource bindings and a task-specific contract. Keep ? for that delegated residual scope. Do not infer arbitrary RAM snapshot/restore (M) from private fallback, or remote-effect compensation (R) from private service/database namespaces.

- Claims: `cua-sandbox-2609.32750:C9`, `cua-sandbox-2609.32750:C10`. Primary locator: v1 §§3.2–3.4; Appendix D Resource contracts, Binding tables, Asynchronous and background execution. Frozen passage: `papers/cua-sandbox-2609.32750/sources/2609.32750v1.txt` lines 316–331, 380–385, 2642–2686, 2784–2837. Concrete F/P with explicitly conditional binding/private-backend coverage; other domains remain contract-dependent.

### 4. BunshinRL — `F, P, M`

The source enumerates process topology/metadata, CoW memory and a filesystem snapshot/private overlay. Internal TCP restoration is local workspace state. External connections reconnect and remote side effects cannot be undone by local rollback, so do not add R.

- Claims: `bunshinrl-2611.10453:B0`, `bunshinrl-2611.10453:Bstate`, `bunshinrl-2611.10453:Bexternal`. Primary locator: v2 §§4.2–4.6. Frozen passage: `papers/bunshinrl-2611.10453/source.txt` lines 417–449. F/P/M are specified; external remote effects are expressly outside the local snapshot contract.

### 5. Planarian — `F, P, M, R*`

CRIU process checkpoints and ZFS snapshots support local P/M/F. Remote rollback uses a service-specific proxy with supported compensable operations; unsupported operations are rejected. Remote fork needs service-native branching, and a compensation-only proxy cannot be used by child branches. R* is therefore an explicit restricted remote domain.

- Claims: `planarian-2609.35366:P-CONSIST`, `planarian-2609.35366:P-COMP`, `planarian-2609.35366:P-FORK`. Primary locator: v1 §§4.3–4.4, 6.1–6.2; Table 2. Frozen passage: `papers/planarian-2609.35366/source.txt` lines 870–880, 1486–1510, 1693–1725. R is positive supported-operation evidence, not a generic remote-state guarantee.

### 6. AgentFly — `H, ?`

The context layer stores rollout inputs/IDs and tracks rollout-to-resource associations for release, supporting H. The resource payload can be a container, model service/API or in-process environment and the backend is pluggable; those generic interfaces do not define one F/P/M/R set. Retain ? rather than turn backend parametrization into concrete domain coverage.

- Claims: `agentfly-2507.14897:AF-C1`. Primary locator: v3 §§2.2.2–2.2.4; Fig. 3. Frozen passage: `papers/agentfly-2507.14897/source-v3.txt` lines 313–348. H concerns rollout/context associations; ? concerns the delegated resource payload.

### 7. Aries — `H, ?`

Trajectory/event identifiers, causal/ordering metadata and the unified trajectory record support H. Concrete environment state continuity is delegated to sandbox adapters, while initial state/evaluator belong to the task specification. The generic persistent-environment interface is insufficient to assign F/P/M/R as a common state boundary.

- Claims: `aries-2607.29069:A0`. Primary locator: v2 §3; Fig. 2. Frozen passage: `papers/aries-2607.29069/source/aries-2607.29069v2.txt` lines 491–513. H is the described observation/provenance record; environmental state domains remain delegated.

### 8. SpecBox — `?`

Warm describes readiness, not a state-domain type. Preparation is separated from committed side-effecting work and cache reuse has a compatibility/determinism condition; neither specifies a complete state preservation/reset boundary. Do not infer F/P/M from generic container prewarming, or promote its scheduling/cache metadata to a harness/job state contract.

- Claims: `specbox-2607.23933:C1`, `specbox-2607.23933:C2`. Primary locator: v2 §3.3 Eq. 8; §4 Implementation and Execution boundary and correctness. Frozen passage: `papers/specbox-2607.23933/sources/2607.23933v2.txt` lines 1573–1585, 1593–1598. The selected evidence describes preparation/cache conditions while leaving environmental state scope unresolved.

### 9. HAL — `H, ?`

Run/task identifiers, grouped API/tool telemetry, logs and task artifacts support H. The harness accepts benchmark-defined task specifications and backend-specific environments. Unique containers/VMs and artifact copy-back do not establish one common environment F/P/M/R reset/preservation scope, so retain ?.

- Claims: `hal-2510.11977:HAL-03`, `hal-2510.11977:HAL-10`. Primary locator: v1 Appendix A.2 Logging and Task runner. Frozen passage: `papers/hal-2510.11977/sources/paper-v1-html.txt` lines 1759–1766, 1769–1782. H is explicit task-run telemetry/artifacts; the environment payload remains task/backend dependent.

### 10. AgentGym-RL — `?`

The common contract is observation/step/reset with exclusive clients; concrete reset state is defined by each environment. Chromium subprocesses, SciWorld reset fixes and TextCraft/SciWorld memory repairs are examples of implementation work, not a common F/P/M/R preservation contract. The WebArena experiment excludes state-changing Content & Config tasks. Batch trajectory collection alone is not promoted to an H lifecycle-state contract in this row.

- Claims: `agentgym-rl-2509.08755:AGRL-C1`, `agentgym-rl-2509.08755:AGRL-C2`, `agentgym-rl-2509.08755:AGRL-C3`, `agentgym-rl-2509.08755:AGRL-C4`. Primary locator: v1 §3.1 p.5; §3.2.3 p.7; Appendices A p.31 and B.1 p.32. Frozen passage: `papers/agentgym-rl-2509.08755/sources/2509.08755v1.txt` lines 247–260, 313–345, 1574–1579, 1638–1645. Selected corrections do not resolve the generic environmental state scope.

### 11. AWorld — `H, ?`

Message session/task/trace context, synchronized storage and centralized trajectory/metric collection support H. Pods identify execution units, not their preserved environment state domains. Remote storage of traces is H storage, not evidence that the framework controls external service side effects (R). Retain ? for the task-environment boundary.

- Claims: `aworld-2508.20404:AW-D2`, `aworld-2508.20404:AW-D3`, `aworld-2508.20404:AW-D1`. Primary locator: v2 §§2.2–2.4; Figs. 4–5. Frozen passage: `papers/aworld-2508.20404/sources/paper-v2.txt` lines 125–153, 154–166. H has direct support; concrete environmental state scope is not enumerated.

### 12. Agent Lightning — `H, ?`

Gateway rollout IDs/status/events and controller Job/process orchestration directly support H. The source assigns context/control/tool/environment interaction to the connected harness, so environmental F/P/M/R scope is delegated. Local process orchestration is coded as H job state, not a P process-state checkpoint/reset guarantee.

- Claims: `agent-lightning-v1-2608.17528:ALV1-C1`, `agent-lightning-v1-2608.17528:ALV1-C2`. Primary locator: v1 §3; Appendix A.1–A.2 pp.19–21. Frozen passage: `papers/agent-lightning-v1-2608.17528/sources/arxiv-v1.txt` lines 529–572, 1106–1134, 1180–1205. H is explicit; ? preserves the delegated harness/environment scope.

### 13. GKE RL packet — `F*, P*`

The code resets a repository, wipes selected paths and sweeps processes. Optional environment/config tripwires default off, detect rather than restore those domains, and process hygiene is expressly unverified in the inspected comment. Put the restriction marker on the domain codes rather than the unrelated free-text token checks.

- Claims: `gke-agent-sandbox-rl-20260929:GKE-RESET`. Primary locator: cutoff 454d3353e5c26c561dd6de389f32f7f285030e38 recycle.py:84–105,179–245. Frozen passage: `papers/gke-agent-sandbox-rl-20260929/sources/code/agent_sandbox_rl/recycle.py` lines 84–105, 179–245. Positive F/P reset code, restricted selected coverage; no live result is added.

### 14. AgentENV — `F, P, M`

Docs explicitly enumerate VM memory/running processes, rootfs and attached/mounted-drive contents, plus command context. F/P/M is justified as specified snapshot state. It neither establishes deterministic external-service reset nor treats unexecuted tests as local correctness results.

- Claims: `agentenv-kvcache:AE3`. Primary locator: commit 56c218507d3783be5f1c0bf35325b1a521fb94cf docs/src/concepts/snapshots/index.md:1–25. Frozen passage: `papers/agentenv-kvcache/snapshots/docs/src/concepts/snapshots/index.md` lines 1–25. F/P/M are explicitly enumerated snapshot domains.

### 15. OpenSandbox — `F*, P*, M*`

Concrete scopes are enumerated, so generic ? would discard known information: internal init performs best-effort session/process teardown; BatchSandbox rootfs mode captures rootfs but restarts processes and excludes volume contents; opt-in QEMU/FastSandbox adds VM memory/runtime state. Stars mean backend/operation-restricted coverage, not universal F/P/M restoration. Backend choice remains a separate qualifier.

- Claims: `opensandbox:OSB-06`. Primary locator: commit e654726234172564860a76b82d2b26909bbf4aa8 reset.go:21–66. Frozen passage: `papers/opensandbox/source/components/execd/pkg/runtime/reset.go` lines 21–66. P session/process teardown is best effort.
- Claims: `opensandbox:OSB-07`. Primary locator: same commit docs/guides/pause-resume.md:26–96. Frozen passage: `papers/opensandbox/source/docs/guides/pause-resume.md` lines 26–96. Rootfs/volume and process/memory scope depends on pause backend/mode.
- Claims: `opensandbox:OSB-07`. Primary locator: same commit docs/architecture/fast-sandbox/checkpoints.md:12–60. Frozen passage: `papers/opensandbox/source/docs/architecture/fast-sandbox/checkpoints.md` lines 12–60. FastSandbox positively enumerates rootfs, vmstate and memory artifacts.

## Interpretive decisions that matter

- **CUA-Sandbox:** files, profiles/sessions and context-bound process state are concrete, but arbitrary RAM capture and external remote-effect compensation are not established by those passages. Private fallback is a coverage condition, not evidence to invent M/R. The task resource contract leaves residual domain scope delegated, hence `?`.
- **AgentFly/Aries/HAL/AWorld/Agent Lightning:** H records an explicitly described rollout association, trace/event record or Job/lifecycle state. The accompanying `?` preserves the separate environment boundary. This does not recode an unknown backend as an absent capability.
- **AgentGym-RL:** Chromium concurrency and memory-leak repairs identify implementation mechanisms; they do not define a common cross-environment reset state set. Its per-episode API therefore remains `?`. A future environment-specific row could code narrower concrete domains with new primary support.
- **SpecBox:** warm is a readiness condition. Container-based preparation does not identify the maintained/reset state domain. The proposal leaves `?` and keeps cache/commit conditions in the qualifier.
- **OpenSandbox:** explicit F/P/M subsets are available in the primary backend documentation. All three need stars and the backend qualifier; no all-backend or all-operation equivalence is claimed.
- **R:** remote trace storage is storage of H, not automatically control of external service effects. Planarian supplies the positive, restricted R contract in these rows.

## Verification and remaining decision

`coding.json` records all 15 proposals, each supporting primary file/line span, claim IDs, source versions/URLs and SHA-256. The build validates row uniqueness, source-span bounds and every cited claim ID. The report proposes a rule change and recoding checkpoint; it does not silently modify the original frozen extraction codebook. The coordinator should adjudicate these proposals and record the revised rule before updating the manuscript/evidence table.
