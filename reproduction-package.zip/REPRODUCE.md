# Reproduction guide

## 1. Inspect and recompute existing evidence

Use the three offline commands in README. They verify package hashes and reproduce the main02analysis without executing native service or Docker commands. `data/trials-18.json` is the readable main02selection; `native/runs/` retains complete raw evidence and earlier attempts. The stopped main01is not pooled into main02.

## 2. Run a new native campaign

Use a fresh Python3.12environment and an intended local Docker context. Source pin: OpenSandbox `e654726234172564860a76b82d2b26909bbf4aa8`. Download that public source into `native/code/cancellation-pilot/upstream/opensandbox/repo/`, next to `native/code/c01-lost-reply/`. The prior scheduling implementation is not required. Dependency versions are in `config/requirements-freeze.txt`; server and SDK requirements come from the pinned public source. Cache the exact task and execd images in `config/perimeter.json`; the experiment refuses image pulls and unrelated-object mutation.

Run from `native/code/` using the source/SDK PYTHONPATH and example commands in `c01-lost-reply/README.md`. Select a new run ID/output directory and pass the explicit `--authorize-native` marker. Run a six-cell pilot first; the18trial main phase requires a verified pilot and a separate prospective freeze. Follow the protocol, observer-r2amendment and analysis plan; do not overwrite frozen records.

## 3. Interpret the measurements

The proxy receives upstream202, verifies a live target and withholds all downstream response bytes. SDK cancellation settles and closes its transport before response release. Known-ID cancellation and normal destroy are controls. Lifetimes are60s or explicit manual cleanup (`None`); management timeout120s is separate. The exact-label read-back rule handles list/inspect deletion races. Manual targets are observed beyond30s then removed administratively; finite lost-ID targets are observed through expiry plus15s or confirmed absence. Every trial records signed observation brackets and an unrelated sentinel.

See `protocol/EXPERIMENT_HISTORY.md` for both pilots and the stopped/amended main run. Preserved source-defined tests and model artifact audits are distinct from native execution and from human review. The resource-policy ledger is constructed arithmetic.
