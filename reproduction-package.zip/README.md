# Supplementary reproducibility package

Start with `literature/primary_recheck_20261118/RECHECK_32.md`: the completed 32-assertion model-assisted source audit, with one record per assertion, source versions/locations/hashes and precision corrections. Original dated audits remain as history.

- `literature/COHORT_54.md` and `.json`: all 54 candidates, with 23 detailed, 28 context and 3 excluded records, reading depths, decisions and rationales.
- `data/trials-18.md` and `.json`: all 18 reported native trial rows, signed timing brackets and censoring.
- `config/`: perimeter rules, resource/image/source pins and actual configuration.
- `native/code/c01-lost-reply/src/`: exact proxy/driver, scoped Docker perimeter and common code.
- `native/runs/`: full raw main data and separate pilots/stopped-run history; `protocol/` preserves protocol, amendment and prospective freeze.
- `literature/claims.jsonl`: original 251-entry working ledger; the new source audit is an additional layer.
- `literature/human_source_checks/CURRENT.json`: one completed guided human check plus partial RT-03 confirmations, kept distinct from model verification. No human inter-rater agreement is reported.

## Offline verification

Python 3.12, no Docker or model API:

```sh
python3 tools/verify_package.py
python3 native/code/c01-lost-reply/analyze.py native/runs/20261115-c01-main-02 --out /tmp/c01-recomputed-NEW.json
python3 literature/illustrative-ledger/recompute.py
```

Choose a new analysis output path. See REPRODUCE.md for native setup. This revision updates derived audit/documentation only; native records and executable experiment code are unchanged. Original papers are linked, not redistributed. Main02 contains 18 valid trials; early main01 remains 5 valid, 1 invalid and 12 unstarted, separately retained. Manual retention is censored; the default 600-second lifetime and crash/restart behavior were not tested. The numerical resource ledger is constructed.
