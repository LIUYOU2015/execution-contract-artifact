# Supplementary reproducibility package

This artifact supports the execution-contract comparison and the C-01 pending-create cancellation study. Start with the complete candidate inventory and the18trial table, then verify the package offline.

- `literature/COHORT_54.md` and `.json`: all54stable source IDs, URLs/versions, reading roles, original decisions and rationales. Counts are23detailed /28context /3excluded. Original depth is explicit, including the partially accessible survey.
- `data/trials-18.md` and `.json`: every reported main02trial, signed removal brackets, censoring and later administrative cleanup.
- `config/perimeter.json`, `executed-server.toml` and dependency captures: ownership/quotas, image/source pins and actual configuration.
- `native/code/c01-lost-reply/src/experiment.py`: proxy and native trial driver; `server.py`: scoped Docker perimeter; `common.py`: pins and logging.
- `native/runs/`: full main02raw events, request/response bodies, observations, results and freeze. Both pilots and stopped main01 are retained separately.
- `protocol/`: protocol, observer amendment, prospective freeze and complete experiment history.
- `literature/claims.jsonl`:251original working assertions; versioned32record model-assisted recheck and state-domain adjudication are separate records.
- `literature/illustrative-ledger/`: constructed CPU/memory/fee accounting example and recomputation script.

## Offline verification (Python3.12; no Docker or model API)

```sh
python3 tools/verify_package.py
python3 native/code/c01-lost-reply/analyze.py native/runs/20261115-c01-main-02 --out /tmp/c01-recomputed-NEW.json
python3 literature/illustrative-ledger/recompute.py
```

Choose a new analysis output path; the analysis script refuses overwriting. The verifier checks all file hashes,54candidate roles,18trial identities and all native main02analysis fields against preserved raw records. See `REPRODUCE.md` for native-run setup and scopes. Textual author-local paths were sanitized in the earlier anonymous native release; original/released hash mappings remain in `native/MANIFEST.json`. Primary-source papers are linked rather than redistributed.

Main02has18valid trials. Earlier5valid/1invalid/12unstarted main01records are separate history. The measured window is cancellation after backend acceptance before SDK ID delivery. Manual retention is right-censored; default600s lifetime, backend crash/restart and proxy-free cancellation sweeps were not tested. Source audits are model-assisted and carry no human agreement estimate.
