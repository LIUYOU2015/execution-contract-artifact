# C-01: cancellation after an accepted create loses its ID response

Start with `STATE.md`, `PROTOCOL.md`, `AMENDMENT_OBSERVER_R2.md`, and `ANALYSIS_PLAN.md`. This local CPU/Docker study uses the real pinned OpenSandbox Python SDK and lifecycle HTTP server, a loopback response-gating proxy, and real containers. The scoped Docker perimeter limits ownership/quotas and instruments expiry; it does not supply a cleanup repair. Prior cancellation-scheduling study results are separate.

Source pin: `e654726234172564860a76b82d2b26909bbf4aa8`. Official execd and Python image digests are in `src/common.py`; both cached images are Linux/amd64. The live experiment refuses image pulls. Python environment `env/` is isolated for new SDK dependencies and reads the existing pinned server dependency pool via `prior-server-deps.pth`; it does not change that pool. Every run captures its full `requirements-freeze.txt` and all573 upstream Python source hashes. The pinned source archive/hash and independent archive comparisons are recorded under reviews/.

The source directory is `../cancellation-pilot/upstream/opensandbox/repo/` relative to this study. A standalone reproduction can place the public pinned archive at that same relative location; the prior scheduling adapter is not imported or needed. Install the server and SDK dependencies in a fresh Python3.12 environment, cache both exact images, use a local Docker context, then run the checked-in scripts. Ports and run-local SQLite/metadata paths are selected per run; do not reuse an output directory.

Example commands from the survey root (explicit local native run marker):

```sh
c01-lost-reply/env/bin/python -m unittest discover -s c01-lost-reply/tests -v
PYTHONPATH=c01-lost-reply/src:cancellation-pilot/upstream/opensandbox/repo/sdks/sandbox/python/src:cancellation-pilot/upstream/opensandbox/repo/server c01-lost-reply/env/bin/python c01-lost-reply/src/experiment.py --run-id NEW-UNIQUE-ID --out c01-lost-reply/runs/NEW-UNIQUE-ID --phase pilot --authorize-native
c01-lost-reply/env/bin/python c01-lost-reply/analyze.py c01-lost-reply/runs/NEW-UNIQUE-ID
```

Main phase requires a verified six-arm pilot and separate prospective freeze. It runs18 trials, three in each operation×lifetime cell, in the seeded order. The native SDK management timeout is120s; lifetime TTL is a separate60s/None factor. Normal requests destroy after SDK readiness. Known-ID cancellation occurs at endpoint lookup; lost-ID cancellation occurs after upstream202 and confirmed provisioning while all downstream create-response bytes are withheld. Observers/admin traffic stay separate from SDK lifecycle traffic and do not restore the SDK's missing ID.

Raw records: `events.jsonl` (driver/proxy/samples), `server-events.jsonl` (HTTP/native/expiry events), `http/*` (request/response bytes), each trial's result/observations, freeze/dependencies/environment, sentinel checks, and stopped-server final exact-owned inventories. Observation errors remain explicit. A404 caused by concurrent deletion is accepted as disappearance only after an empty exact-label readback; uncertain/replaced or failed readbacks remain errors. Nominal .25s sampling plus inspection cost yields actual timestamped brackets, not exact transition times.

History is retained: pilot01 valid6/6; main01 stopped at an observer404 with5completed-valid/1invalid/12unstarted. Observer-r2 fresh runs are not pooled with them. Pilot01's first offline selector erroneously counted telemetry POSTs; the corrected selector/old output are both preserved. Native raw data are unchanged.

Finite lifetime can supply a server backstop independently of SDK cancellation. `timeout=None` explicitly requests manual cleanup; retained objects at the30s scientific horizon are right-censored then removed administratively. This design does not estimate production prevalence or permanent leaks, and it does not test server-owner crash/restart. Public hosting, manuscript submission and outreach are separate actions.
