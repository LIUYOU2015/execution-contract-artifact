from pathlib import Path
import json,argparse,statistics
ap=argparse.ArgumentParser();ap.add_argument('analysis',type=Path);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();d=json.loads(a.analysis.read_text())
lines=['# C-01 native result table','',f"Run `{d['run_id']}`: {d['valid']}/{d['planned']} valid, {d['invalid']} invalid/incomplete started, {d['missing']} unstarted/missing planned.",'','| Path | Lifetime | n | SDK DELETE trials | Present beyond30s | TTL removal | Censored/admin |','|---|---|---:|---:|---:|---:|---:|']
for c in d['cells']:
 n=c['valid_n'];lines.append(f"| {c['arm']} | {str(c['lifetime_s'])+'s' if c['lifetime_s'] else 'manual (None)'} | {n} | {c['sdk_delete_trials_n']}/{n} | {c['present_beyond_30s_n']}/{n} | {c['expiry_removed_trials_n']}/{n} | {c['right_censored_n']}/{n} / {c['post_horizon_admin_n']}/{n} |")
lines+=['','Observation offsets use SDK destroy return for normal controls and cancellation return for fault arms. Samples are bracketed by actual inspection times. Finite TTL starts before provisioning; manual retention is censored and administrative deletion is after the scientific horizon. Pilot/prior attempts are separate, not pooled.','']
a.out.write_text('\n'.join(lines));print('\n'.join(lines[:12]))
