import unittest,sys,asyncio,tempfile
from pathlib import Path
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from server import API,Scoped
from common import *
from experiment import Proxy,TrialGate,port,Experiment
from types import SimpleNamespace
from aiohttp import web
import httpx
class Perimeter(unittest.TestCase):
 def test_foreign_remove_never_reaches_docker(self):
  raw=Mock();owner=Mock();owner.check.side_effect=PermissionError('foreign')
  api=API(raw,owner)
  with self.assertRaises(PermissionError):api.remove_container('foreign-id',force=True)
  raw.remove_container.assert_not_called()
 def test_unlabeled_create_refused_before_native(self):
  raw=Mock();owner=Mock();owner.study='unit-study';api=API(raw,owner)
  with self.assertRaises(PermissionError):api.create_container(image=TASK_IMAGE,labels={})
  raw.create_container.assert_not_called()
 def test_scoped_filters_retain_original_and_exact_study(self):
  owner=object.__new__(Scoped);owner.study='one'
  self.assertEqual(owner.filters({'label':'trial=two','status':'running'}),{'label':['trial=two',f'{STUDY_KEY}=one'],'status':'running'})
class ProxyWindow(unittest.IsolatedAsyncioTestCase):
 async def test_full_response_withheld_until_client_cancelled(self):
  app=web.Application()
  async def accepted(request):return web.json_response({'id':'controlled-backend-id'},status=202)
  app.router.add_post('/v1/sandboxes',accepted);runner=web.AppRunner(app);await runner.setup();up=port();await web.TCPSite(runner,'127.0.0.1',up).start()
  with tempfile.TemporaryDirectory() as d:
   events=Events(Path(d)/'events.jsonl');proxy=Proxy(f'http://127.0.0.1:{up}',Path(d),events);await proxy.start();g=TrialGate('unit','lost_id_cancel');proxy.active['unit']=g
   async with httpx.AsyncClient() as client:
    task=asyncio.create_task(client.post(f'http://127.0.0.1:{proxy.port}/v1/sandboxes',headers={'x-c01-trial':'unit'},json={}))
    await asyncio.wait_for(g.gate.wait(),5);self.assertFalse(task.done());self.assertEqual(g.creates[0]['body']['id'],'controlled-backend-id')
    self.assertTrue(task.cancel());done,_=await asyncio.wait({task},timeout=2);self.assertIn(task,done)
    with self.assertRaises(asyncio.CancelledError):task.result()
    log=(Path(d)/'events.jsonl').read_text();self.assertNotIn('proxy_response_released',log)
    g.release.set();await asyncio.sleep(.05)
    self.assertIn('\"transport_closing_or_gone\": true',(Path(d)/'events.jsonl').read_text())
   await proxy.close()
  await runner.cleanup()
class StrongerPerimeter(unittest.TestCase):
 def owner(self,role='target'):
  o=object.__new__(Scoped);o.study='unit';o.events=Mock();o.identities={'cid':('trial-a',role)};o.original_api=Mock()
  o.original_api.inspect_container.return_value={'Id':'cid','Config':{'Labels':{STUDY_KEY:'unit',TRIAL_KEY:'trial-a',ROLE_KEY:role}}}
  return o
 def test_registered_identity_required(self):
  o=self.owner();o.identities={}
  with self.assertRaises(PermissionError):o.check('cid',mutation=True,operation='remove')
 def test_cross_trial_write_refused(self):
  o=self.owner();token=TRIAL_CONTEXT.set('other')
  try:
   with self.assertRaises(PermissionError):o.check('cid',mutation=True,operation='remove')
  finally:TRIAL_CONTEXT.reset(token)
 def test_same_study_sentinel_cannot_be_deleted_by_sdk(self):
  o=self.owner('sentinel');tt=TRIAL_CONTEXT.set('trial-a');aa=ACTOR.set('sdk')
  try:
   with self.assertRaises(PermissionError):o.check('cid',mutation=True,operation='remove')
  finally:TRIAL_CONTEXT.reset(tt);ACTOR.reset(aa)
 def test_pull_is_forbidden(self):
  with self.assertRaises(PermissionError):API(Mock(),self.owner()).pull('anything')
 def test_target_helper_target_keeps_parent_trial(self):
  o=self.owner();native=Mock();native.containers.return_value=[];native.create_container.side_effect=[{'Id':'target-id'},{'Id':'helper-id'}];api=API(native,o)
  target={STUDY_KEY:'unit',TRIAL_KEY:'trial-a',ROLE_KEY:'target'};helper={STUDY_KEY:'unit',TRIAL_KEY:'trial-a',ROLE_KEY:'helper'}
  tt=TRIAL_CONTEXT.set(None)
  try:
   api.create_container(image=TASK_IMAGE,labels=target,host_config={'NanoCpus':1000000000,'Memory':256*1024**2,'MemorySwap':256*1024**2,'PidsLimit':64})
   api.create_container(image=EXECD_IMAGE,labels=helper,host_config={'NanoCpus':250000000,'Memory':128*1024**2,'MemorySwap':128*1024**2,'PidsLimit':64})
   self.assertEqual(TRIAL_CONTEXT.get(),'trial-a')
   def inspect(ident):return {'Id':ident,'Config':{'Labels':helper if ident=='helper-id' else target}}
   o.original_api.inspect_container.side_effect=inspect
   api.start('helper-id');api.remove_container('helper-id',force=True);api.put_archive('target-id','/tmp',b'x');api.start('target-id')
  finally:TRIAL_CONTEXT.reset(tt)
class LateCleanup(unittest.IsolatedAsyncioTestCase):
 async def test_inventory_and_remove_happen_after_server_stop(self):
  with tempfile.TemporaryDirectory() as d:
   o=object.__new__(Experiment);o.out=Path(d);o.study='unit';o.events=Events(Path(d)/'events.jsonl');state={'stopped':False,'removed':False}
   class Proc:
    returncode=None
    def poll(self):return self.returncode
    def terminate(self):state['stopped']=True;self.returncode=0
    def wait(self,*a):return self.returncode
   class Container:
    id='late-cid';attrs={'Config':{'Labels':{STUDY_KEY:'unit',TRIAL_KEY:'trial-a',ROLE_KEY:'target'}}}
    def remove(self,**kw):assert state['stopped'];state['removed']=True
   def listing(**kw):
    self.assertTrue(state['stopped'])
    return [] if state['removed'] else [Container()]
   o.server=Proc();o.raw=SimpleNamespace(containers=SimpleNamespace(list=listing))
   final=await o.final_native_cleanup();self.assertEqual(final,[]);self.assertTrue(state['removed'])
class ObserverRace(unittest.TestCase):
 def observer(self,root):
  e=object.__new__(Experiment);e.study='unit';e.events=Events(Path(root)/'events.jsonl');e.raw=SimpleNamespace(api=Mock());return e
 def test_disappearance404_requires_empty_readback(self):
  import docker
  with tempfile.TemporaryDirectory() as root:
   e=self.observer(root);e.raw.api.containers.side_effect=[[{'Id':'gone'}],[]];e.raw.api.inspect_container.side_effect=docker.errors.NotFound('gone')
   row=e.snapshot('trial');self.assertEqual(row['objects'],[]);self.assertEqual(len(row['confirmed_disappearance_readbacks']),1);self.assertEqual(e.raw.api.containers.call_count,2)
 def test_still_listed404_stays_uncertain(self):
  import docker
  with tempfile.TemporaryDirectory() as root:
   e=self.observer(root);e.raw.api.containers.side_effect=[[{'Id':'gone'}],[{'Id':'gone'}]];e.raw.api.inspect_container.side_effect=docker.errors.NotFound('gone')
   with self.assertRaises(RuntimeError):e.snapshot('trial')
 def test_failed_readback_not_converted_to_absence(self):
  import docker
  with tempfile.TemporaryDirectory() as root:
   e=self.observer(root);e.raw.api.containers.side_effect=[[{'Id':'gone'}],RuntimeError('observer unavailable')];e.raw.api.inspect_container.side_effect=docker.errors.NotFound('gone')
   with self.assertRaises(RuntimeError):e.snapshot('trial')
if __name__=='__main__':unittest.main()
