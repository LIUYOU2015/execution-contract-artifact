# C-01 accepted create / lost ID reply protocol v1

Date: 2026-11-15 America/Los_Angeles. Stage PILOT; user explicitly authorized a $0 local Docker HTTP-proxy experiment. This is a mechanistic correctness/retention experiment, not prevalence, scalability, learning-quality or permanent-leak estimation.

## Question and hypothesis

For pinned OpenSandbox server and Python SDK e654726234172564860a76b82d2b26909bbf4aa8, after a real Docker create succeeds but the HTTP response containing its ID is withheld from the SDK, what does cancellation do, and does server TTL subsequently reclaim the container? The SDK's known-ID failure branch is a control, not a presumed equivalent operation.

## Execution path and constraints

Native pinned SDK Sandbox.create -> loopback fault proxy -> actual pinned lifecycle HTTP API -> native DockerSandboxService -> real Docker container and official execd. The pinned upstream tree stays unmodified. A minimal Docker-client perimeter adds exact experiment labels, scoped discovery/write ownership checks, unique native task names, prefixed helper names and quotas; it does not retain SDK create ownership, recover lost IDs for the caller, call delete after cancellation or change TTL logic. Any process-local metadata/repository path is redirected into this run. The test observer may know server IDs; those IDs must never be passed to the cancelled SDK task. All observer/admin calls are separately tagged/logged.

No prior cancellation-pilot adapter is used in the SDK/control path; prior results are not pooled. Existing Kind/buildkit/foreign resources are read-only. No Docker prune, global context change, host credential handling, volume operations or source edits. Cached pinned python image and official execd digest reused. One target (1 CPU,256 MiB,pids64), one distinct sentinel (.1 CPU,128 MiB,pids64), transient execd extraction helper (.25 CPU,128 MiB,pids64); no overlapping trials. No image/network/volume creation beyond actual required containers/port mappings.

## Arms and order

Factorial 3 operations x 2 lifetime settings: (A) normal response, healthy SDK create, explicit destroy; (B) response delivered, gate first SDK endpoint GET as proof ID delivery, cancel initialization; (C) upstream 202/body received by proxy after actual provisioning, withhold all response headers/body to SDK, cancel its pending create. Each uses TTL60 seconds or SDK timeout=None (explicit manual cleanup).

Pilot: one trial per six arms, fixed order [normal60,known60,lost60,normalNone,knownNone,lostNone]. These validate the harness and are not pooled into main. If all validity gates pass, separately freeze main code/config/source/order: three repetitions of all six arms (18 trials), deterministic shuffled order using seed20261115. No outcome-based selection or rerun. Pilot failures stay in raw artifacts; revisions receive new attempt/run ID and amendment before a new pilot.

## Fault validation and observations

Proxy records full upstream create status/body and timestamps before gating. A real container with matching experiment+trial labels must exist at injection; upstream create must return202 and an ID. In arm C, no create response is sent to SDK until its task cancellation has completed; a cancelled SDK transport disconnect and absence of SDK endpoint/DELETE requests are recorded, not assumed. In B, at least one ID-bearing endpoint GET reaches the proxy before cancellation. Release gated handler only after SDK task settles, without sending an ID to any resumed SDK task. Retry configuration uses the pinned SDK default; request counts/IDs detect duplicates. Any duplicate create invalidates a single-create interpretation but remains recorded.

Record requested, backend-accepted/provisioned, proxy-ID-known, SDK-ID-observed (via endpoint GET), SDK-ready (successful create return), backend-ready (independent observer /ping), cancellation request/return, DELETE requests, running/stopped/absent objects, scheduled expiry and administrative cleanup. Observer readiness is not SDK readiness. Sample exact-target Docker state every .25s; first absent observation brackets deletion with prior present sample. Clock pairs use monotonic_ns+wall_time_ns; >2s incremental wall/monotonic disagreement invalidates timing claims, retaining raw outcomes.

A separate sentinel remains live, with same container identity and marker file checked before/after each trial. Never delete it as target cleanup; remove it only during final administrative cleanup.

## Endpoints, horizon and accounting

Primary: target still allocated at cancellation return and at10s after SDK terminal return; SDK DELETE attempted; container absence by30s after terminal return. Finite-TTL lost-ID arm continues to scheduled expiry+15s (at least30s after cancellation); report whether/when TTL removal occurs and whether it followed the explicit expiry timer event. Manual-lifetime lost-ID arm is observed to30s after SDK cancellation returns; if present, report right-censored retention and perform separately labeled exact-owned administrative deletion after the scientific endpoint. Do not report bounded retention as a permanent leak. Normal/known-ID controls observe confirmed absence or30s.

Full raw request/status/response bodies, native Docker events/state snapshots, upstream logs and sentinel checks retained. Totals distinguish planned/started/completed/valid/invalid/missing, intentional fault vs unexpected failure, and natural/backend cleanup vs post-horizon administration. Paper table may present per-arm counts, median/range observation brackets and censoring; not a confidence interval/population rate from n=3.

## Validity / stop rule

Do not start main until all six pilot arms reach their intended gates, healthy create/ready/destroy works, sentinel survives, proxy withholding is verified, and exact-owned cleanup leaves zero trial containers. Unexpected healthy-control failure, foreign-access guard, resource limit violation, unknown outstanding native create, source hash drift or observer failure halts new admissions, preserves incomplete records and triggers exact-owned administrative cleanup. One API request's backend cleanup latency is distinct from later admin cleanup; no retry erases an outcome. No fault arm is required to reclaim quickly to count as a valid observation.

Completion: pilot + frozen18-trial campaign (or documented incomplete/blocked result), independent source/proxy/raw-result audit, exact-owned cleanup and checked manifest, result report with strongest scoped claim, STATE updates. If evidence supports manuscript addition, integrate one compact table without exceeding8content pages; preserve missing/invalid results and necessary evidence-type distinctions. Public release/submission/organizer messages remain outside scope.

## Pre-native implementation clarifications

Installed perimeter/path redirects precede native service construction. An observation-only wrapper delegates the native expiry callback unchanged while logging entry/exit and tagging its Docker actions as expiry_timer. Management HTTP timeout is120s (distinct from lifetime TTL), default SDK retry policy retained; one explicit task.cancel is followed by asyncio.wait without another watchdog cancellation. Normal arm timing uses destroy request/return; fault arms use cancellation request/return; inapplicable fields are null. FREEZE.json/order/upstream+driver hashes and dependency freeze are written before server startup/sentinel creation. Time horizons use absolute monotonic anchors; remaining TTL derives from the captured server response's createdAt/expiresAt and paired wall/monotonic clock capture. Native source files remain byte-identical to pinned archive.

## Independent audit implementation clarifications (before pilot)

Continuous exact-target sampling starts with SDK creation and spans injection/cancellation/cleanup; pre-create absence is retained but excluded from deletion endpoints. Code uses an explicit cached Linux/amd64 platform and refuses image pulls. Foreign/write perimeter also validates exact trial/role and registered container identity; sentinel lifecycle removal is refused during trial traffic. Backend-readiness observer errors remain null/error, not false. Proxy records actual downstream transport closure before releasing withheld replies. Clock-pair checks span the full trial samples. Final teardown stops the native process first, then exact-owned Docker cleanup and three quiet inventories; failed/unsettled creates remain incomplete. No native trial has run on earlier implementation.
