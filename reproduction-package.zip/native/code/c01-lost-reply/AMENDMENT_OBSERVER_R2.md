# Observer-race and incomplete-accounting correction (before fresh pilot02/main02)

Main01 halted at trial6 (normal TTL60): Docker list returned a target, then its inspect returned404 after native deletion. Per original protocol this was an observer failure, so main01 remains5completed+1invalid/incomplete+12unstarted. Final owned cleanup empty. No sample or failure is overwritten or pooled into02.

Change only independent observation: use raw Docker container summaries to avoid the high-level list's implicit inspection race. Inspect each exact study/trial/role object. A404 triggers a fresh exact-label list: only absence of that immutable container ID (and no replacement) confirms its disappearance; record the initial list,404 and readback timing. A still-listed ID, replacement or failed readback is uncertain/error and halts admissions. Do not turn generic inspection errors/timeouts into absence. Sampling endpoints, arms, SDK/proxy/native backend, quotas, platform, lifetimes, retry policy, sentinel, order/seed and horizons stay fixed.

Offline count clarification: report invalid/incomplete started trials separately from unstarted planned trials, rather than deriving invalid solely as completed-minus-valid. Existing valid pilot fields are unaffected. Corrected analysis is prospective for02 and also reports01 with a new output filename.

Requirements: CPU cases for confirmed disappearance, uncertain404 and failed readback; independent delta review; NEW full six-arm pilot02, then NEW frozen18-trial main02 after raw pilot audit. Main01 and pilot01 remain separate historical evidence. Preserve source snapshots before amendment and zero-owned final cleanup. No paid/native policy changes or outcome-based sample replacement.
