# Native C-01 evidence

This directory contains the preserved anonymous native release: code, main02raw records, separate pilots/stopped main01history and model artifact audits. See the package README and REPRODUCE.md for inspection and execution. `MANIFEST.json` maps original raw bytes to sanitized release bytes. The wrapper replaces this overview only; raw records and executable code retain their released bytes.
