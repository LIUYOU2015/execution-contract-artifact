# C-01 main02 independent final audit

Run: `20261115-c01-main-02`. Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor`.

**Final raw-artifact audit: PASS.** The campaign has **18 planned / 18 started / 18 completed / 18 valid / 0 invalid / 0 missing**, with three trials in every cell. All429 independent campaign/trial checks pass. The audit independently compares276 reported trial/cell fields with raw reconstruction. No native action was issued by the auditor.

## Verified result

| Operation | Server lifetime | Valid trials | SDK DELETE trials | Allocated in first post-return sample | Attributed outcome |
| --- | --- | --- | --- | --- | --- |
| normal create/destroy | 60s | 3 | 3 | 0 | SDK-requested native removal before destroy returned. |
| known-ID cancellation | 60s | 3 | 3 | 0 | SDK-requested native removal before cancellation returned. |
| lost-ID cancellation | 60s | 3 | 0 | 3 | Present beyond30s; all3 removed through the native expiry callback. |
| normal create/destroy | manual | 3 | 3 | 0 | SDK-requested native removal before destroy returned. |
| known-ID cancellation | manual | 3 | 3 | 0 | SDK-requested native removal before cancellation returned. |
| lost-ID cancellation | manual | 3 | 0 | 3 | Present beyond30s; all3 right censored, then separately removed by administration. |

The six lost-ID trials have no SDK endpoint or DELETE request. Each records a full upstream202 before the response gate, a pending SDK create task, one accepted cancellation, terminal `CancelledError`, downstream transport closure, and release of the single create response afterward. Failure-telemetry POSTs remain separately recorded and contain no recovered sandbox ID. All12 fault trials have exactly one pending-task cancellation; all six known-ID trials have ID-bearing endpoint requests before cancellation and a native SDK DELETE afterward.

Every trial has exactly one create POST/202 body and a unique target ID, native creation/start before the202, and one matching running object at injection. Allocated observations retain the exact identity, study/trial/role and declared resource limits. All12 fault readiness observations return200; normal controls record native SDK readiness success. Trial admissions do not overlap.

## Signed observation brackets and cleanup cause

The finite lost-ID disappearance brackets, in seconds relative to SDK cancellation return, are:

| Trial | Last observed present | First observed absent |
| --- | --- | --- |
| t07 | 58.423661379 | 58.678025079 |
| t10 | 58.629752309 | 58.888246882 |
| t13 | 58.498302441 | 58.753531510 |

Each has one matching native expiry callback and an expiry-tagged target removal, consistent with the response/label expiry instant and inside its measured disappearance bracket. There is no SDK or admin target deletion in those three trials. Finite lifetime starts at server creation time; these values are relative to cancellation return.

The manual lost-ID last scientific presence samples are30.143627870s,30.280572620s and30.158826668s after return. All have null expiry/manual-cleanup labels, no expiry callback and no scientific-window absence. Their saved scientific records precede administrative cleanup, which starts after the declared horizon. These are right-censored retention observations.

All normal and known-ID native removals complete before SDK terminal return. Preserve the two fully negative normal-control brackets exactly:

- `t17-normal-ttl60`: **[-0.272001390,-0.005143486]s**.
- `t18-normal-manual`: **[-0.280846295,-0.010653019]s**.

Their first absence observations completed before SDK return; the signs express event ordering and must not be clamped to zero. Complete signed brackets for all18 trials are in `MAIN02_AUDIT.json`.

The sampler has a nominal0.25s sleep. Actual per-trial median sample intervals range0.253–0.302s, and the maximum recorded interval is2.213s. The maximum recomputed wall/monotonic incremental disagreement is0.074206s, below the frozen2s threshold. Timing claims should use the recorded observation brackets and censoring; fixed0.25s precision and exact instantaneous state between samples are unsupported.

## Observer, sentinel, and final inventory

All four inspect404 readbacks identify the expected immutable target and have empty fresh exact-label readbacks, matched to their enclosing raw observation and timestamps. They occur concurrently with or after successful native removal; no uncertain/failed readback or other observer error was converted to absence. Event locators are preserved for each trial in the JSON audit.

All37 sentinel marker checks succeed for the same running identity: one initial plus before/after every trial. The native lifecycle log has no sentinel kill/remove during trial traffic. Final administration removes the sentinel after the native server stops. Teardown has no outstanding create and no campaign failure, followed by three empty exact-owned inventories and zero remaining owned IDs. The before/after foreign container count is four; recorded native mutations address only the20 newly created target/sentinel/helper identities.

## Freeze, raw coverage, and campaign separation

`PREMAIN_FREEZE_R2.json`, actual `FREEZE.json`, and the independently regenerated seed20261115 order agree on all18 cells and three repetitions per cell. Pre-main code/protocol/analysis-plan/analysis/amendment hashes match current files; native code/protocol/amendment hashes match the actual run freeze and admitted R2 code. Pre-main file metadata precedes the actual freeze, and the actual freeze timestamp precedes native startup. All573 upstream Python hashes match both the frozen manifest and pinned archive.

The independent audit reads1,554 driver/proxy events,587 native-server events,76 request bodies,64 upstream response bodies/metadata files and1,064 frozen trial observations. The12 requests without upstream response packets are the intentionally gated known-ID endpoint requests. All255 hashed run files remained unchanged during the audit. Detailed predicates, raw line locators, source/run hashes, signed brackets and independent cell counts are in `MAIN02_AUDIT.json`.

Campaign accounting remains separate:

| Campaign | Planned | Started | Valid | Invalid/incomplete started | Unstarted |
| --- | --- | --- | --- | --- | --- |
| pilot01 | 6 | 6 | 6 | 0 | 0 |
| main01 | 18 | 6 | 5 | 1 | 12 |
| pilot02 | 6 | 6 | 6 | 0 | 0 |
| main02 | 18 | 18 | 18 | 0 | 0 |

Main01's failed observer case remains invalid/incomplete under its original rules, with source/freeze/raw failure retained. Its native cleanup succeeded concurrently with the404; that does not retroactively validate the original observation. Neither pilot nor main01 is pooled into main02.

The defensible manuscript result is the measured behavior of this pinned local Docker path under these response-withholding schedules: cancellation before ID delivery produces no ID-bearing SDK cleanup request, finite server lifetime removes the accepted allocation independently, and manual lifetime leaves bounded observed retention until administration. This audit validates the local counts, attribution and reproducibility record; it supplies no permanent-leak or population-prevalence estimate.
