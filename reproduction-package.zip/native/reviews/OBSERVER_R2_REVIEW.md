# Observer R2 independent delta review

Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor`.

**Fresh six-arm pilot02 admission: PASS.** The correction preserves the experimental operation and handles a confirmed disappearance in the independent observer. Main02 admission remains conditional on the new pilot02 raw audit. Main01 remains separate, incomplete evidence; no sample is reclassified or pooled.

## Main01 failure attribution

The first and only recorded observation error occurs in `t06-normal-ttl60`. Its CID and SDK sandbox ID match the accepted create response, injection observation, native mutation log, and DELETE request. Relative to the explicit destroy request, the raw sequence is:

| Event | Seconds after destroy request | Primary locator |
| --- | --- | --- |
| Native target removal completes, actor `sdk` | 0.254758 | `runs/20261115-c01-main-01/server-events.jsonl:218` |
| Sampler logs inspect404 for that exact CID | 0.268104 | `events.jsonl:215` |
| SDK DELETE response is204 | 0.269492 | `events.jsonl:216` |
| SDK `destroy()` returns | 0.273860 | `events.jsonl:218` |
| Independent post-return sample is empty | 0.280148 | `events.jsonl:219` |

Native removal completed about13.35ms before the observer reported404. This supports an observer lookup concurrent with successful cleanup. The raw error does not identify whether the failed inspect came from the high-level list's implicit inspection or the subsequent reload; both are part of the original observer. Native cleanup returned successfully, while the observer failure correctly invalidated the trial under the original protocol.

The campaign stops after five completed trials and this sixth invalid/incomplete trial. No seventh trial starts. `FAILURE.json` retains the error; `FINAL_CLEANUP.json` records zero remaining owned containers and three empty inventories after server shutdown. `UNSETTLED_AT_TEARDOWN.json` retains campaign failure with no pending proxy creates.

## Delta and accounting

`src/experiment.py:66–82` now gets raw exact study/trial/role summaries and performs the inspect explicitly. Only `docker.errors.NotFound` triggers a fresh list with the same exact labels. An empty readback confirms disappearance; a still-listed ID or any replacement makes the readback nonempty and raises an error. Other inspection errors and failed readbacks propagate as unavailable observations. The successful observation records initial IDs, the404/readback record and timing, and the observer's overall start/end pair. It performs no Docker write.

Method-level AST comparison finds changes only in `Experiment.snapshot` and `Experiment.run`; the latter adds amendment hashes to freeze metadata. SDK calls, proxy, cancellation, lifetimes, quotas, readiness, sampling delay, timing horizons, trial order/seed, administrative cleanup, and primary endpoint logic remain unchanged. `server.py` and `common.py` are byte-identical to the saved snapshot. All four saved protocol/driver snapshots match main01's frozen hashes.

`analyze.py:36` now counts every started nonvalid row as invalid and reports failed/incomplete started rows separately. Independent offline reanalysis gives **18 planned / 6 started / 5 completed / 5 valid / 1 invalid or incomplete / 12 unstarted**. Pilot01's validity, cell outcomes, trial outcomes and cleanup fields remain unchanged by this accounting correction. Main01 is not promoted to verified.

## Verification and next gate

All **13/13** mocked-Docker/local-HTTP tests passed independently, including confirmed404 disappearance, still-listed404 uncertainty, and failed readback. Logs, tested source hashes, snapshot comparisons, original main01 file hashes, and the independent accounting comparison are in `OBSERVER_R2_CPU_TESTS.txt` and `OBSERVER_R2_CPU_CHECKS.json`. The auditor's new reanalysis is stored separately as `OBSERVER_R2_MAIN01_REANALYSIS.json`; original run files remained unchanged during review.

Proceed with a new full six-arm pilot02 and a unique freeze/run directory under `AMENDMENT_OBSERVER_R2.md`. Review its raw observer outcomes and existing gates before a separate full18-trial main02. Keep main01's five completed rows, failure and twelve unstarted slots as historical evidence. No additional baseline or experimental arm is required. The auditor issued no native commands or native mutations.
