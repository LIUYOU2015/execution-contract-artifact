# C-01 implementation closeout

Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor` against the source hashes in `IMPLEMENTATION_CLOSEOUT_CPU_TESTS.json`.

**Pilot admission: PASS. Recommendation: CONTINUE to the six-arm native pilot.** All five implementation findings are closed for the reviewed code snapshot. Main-campaign admission still requires six valid pilot arms, the raw-outcome audit, and verified exact-owned cleanup. No additional study arm or performance baseline is requested.

| Finding | Closure evidence | Verification |
| --- | --- | --- |
| I1: cleanup sampling, clock interval, and horizon | `src/experiment.py:111–119` starts continuous sampling with SDK create; lines157–181 preserve the live injection sample, exclude pre-create absence from removal endpoints, compare clock pairs across trial samples, and set the retained-object horizon to terminal return+30s or finite lost-ID expiry+15s, whichever is later. | Source inspection. Actual native cadence, observation errors, and deletion brackets remain pilot validity gates. |
| I2: late native creation and cleanup inventory | `src/experiment.py:200–221` stops the native server before exact-owned removal/inventory, then checks three quiet inventories; lines259–265 preserve outstanding proxy-create state separately from campaign failure and cleanup. | Mocked late-cleanup test passes and asserts server-stop ordering before discovery/removal. Unresolved creates remain incomplete scientific records. |
| I3: exact ownership, roles, and cached images | `src/server.py:28–29,35–52,75–81` refuses image pulls, validates exact role quotas and capacity, registers immutable IDs, checks study/trial/role/identity, rejects cross-trial mutation, and restricts sentinel lifecycle mutation. `src/experiment.py:111,248` requests the cached linux/amd64 platform explicitly. | Cross-trial, unregistered-ID, same-study sentinel, and image-pull refusal tests pass. |
| I4: observer errors | `src/experiment.py:82–87` returns nullable structured readiness; lines139–140 retain the error and halt the trial when the observer is unavailable. | Source inspection. |
| I5: lost-response downstream disconnect | `src/experiment.py:55–60,148–155` retains the downstream transport, requires closing/gone state after SDK cancellation, records it, and releases the upstream response only after SDK settlement. | The loopback HTTP test passes and asserts the closing/gone observation before teardown. |

During recheck, the newly added helper context guard initially overwrote its owning trial. The current correction at `src/server.py:50,64` keeps the parent context and gives extraction helpers their owning trial. An independent check using installed Docker model classes bound to a fake API exercised target creation → high-level helper creation/start/removal → target archive injection/start. It passed, preserved the owning trial, and confirmed that native models use the wrapped API. Evidence: `PERIMETER_HELPER_REPRO.json`.

All **10/10** current mocked-Docker/loopback-HTTP tests passed independently. Complete logs, command, and tested hashes are in `IMPLEMENTATION_CLOSEOUT_CPU_TESTS.txt` and `.json`; code hashes stayed unchanged during the check. The ten primary upstream files inspected in the protocol review still match their recorded pinned hashes.

The auditor issued no Docker commands or native Docker calls and wrote only under `c01-lost-reply/reviews/`. Native server readiness, actual container provisioning, SDK cleanup, TTL execution, sentinel continuity, and final inventory are observations for the authorized pilot. Any failed gate remains an invalid/incomplete attempt and halts further admissions under the existing protocol.
