# C-01 pilot02 independent raw audit

Run: `20261115-c01-pilot-02`. Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor`.

**Main02 admission: PASS.** All **6 planned / 6 started / 6 completed / 6 valid**, with **0 invalid / 0 missing**. Independent reconstruction passes151 campaign/trial checks. Proceed with the separately frozen18-cell main02 campaign using seed20261115 and the observer-R2 amendment. No additional arm or baseline is required.

The audit read541 driver/proxy events,219 native-server events,28 request-body packets,24 upstream response packets, and363 frozen trial observations. The four proxy requests without an upstream response are the deliberately gated known-ID endpoint requests. Predicates, raw event line locators, source hashes, and run-file hashes are recorded in the distinct `PILOT02_AUDIT.json`; earlier audits remain intact.

| Arm | Lifetime | SDK DELETE | First post-return sample | Scientific outcome |
| --- | --- | --- | --- | --- |
| normal | 60s | 1 | Absent | Native SDK removal completed before destroy returned. |
| known-ID cancellation | 60s | 1 | Absent | Native SDK removal completed before cancellation returned. |
| lost-ID cancellation | 60s | 0 | Allocated | Present beyond30s; disappearance bracket58.769–59.024s after cancellation return, attributed to the native expiry callback. |
| normal | manual | 1 | Absent | Native SDK removal completed before destroy returned. |
| known-ID cancellation | manual | 1 | Absent | Native SDK removal completed before cancellation returned. |
| lost-ID cancellation | manual | 0 | Allocated | Last scientific sample remains present at30.130s after return; right censored, followed by separate admin removal. |

Every trial has one raw SDK create POST and one matching202 response, one native target create/start before that response, and one running exact study/trial/role object with the same sandbox/container IDs at injection. All subsequent allocated samples retain that identity and the declared resource limits. Admission intervals do not overlap.

Each fault arm records one pending-task cancellation, accepted `cancel()`, and terminal `CancelledError`. Known-ID gates contain two ID-bearing SDK endpoint requests before cancellation and one SDK DELETE. Both lost-ID gates withhold create response headers/body, observe downstream transport closure after terminal cancellation, and release the single create response afterward; neither has an SDK endpoint or DELETE request. The separate `/metrics/events` POST remains in the ledger and is excluded from create-response counting. Four independent fault-arm readiness observations returned200; normal arms record successful native SDK readiness.

Observer R2 was exercised by **two** real404/readback sequences, in normal60 and normal/manual (`events.jsonl:47` and `:356`). Both list the expected immutable target CID, have an empty fresh exact-label readback, and occur after that target's native SDK removal completed. Each readback record matches its enclosing raw observation, initial listed IDs, and observation/readback timestamps. No failed or nonempty readback was converted to absence, and no observer error was recorded.

The finite lost-ID target has one expiry callback and one expiry-tagged native removal, within the independently reconstructed disappearance bracket; it has no SDK/admin removal. The manual lost-ID target has a manual-cleanup label, no expiry callback, no scientific absence, and an admin removal after its horizon. All13 sentinel marker checks pass for the same running identity. The sentinel has no native lifecycle deletion during trial traffic and is removed only in final administration after native server shutdown. Teardown has no outstanding create; the final owned inventory is empty after three consecutive empty post-shutdown checks. Foreign container count remains four; recorded native mutations address only the eight created experiment identities.

All573 frozen upstream Python hashes match current files and the pinned archive. Protocol, driver, server, common code and observer amendment hashes match the run freeze; driver files match the admitted R2 snapshot, and freeze creation precedes native startup. The offline analysis source hash matches the corrected accounting implementation. All hashed run files stayed unchanged during this audit. Native observations retain measured brackets and clock pairs; use those brackets rather than fixed0.25s precision claims.

Freeze main02's native code/config/source, corrected analysis hash, amendment and seeded18-cell order before startup. Keep both pilots and main01 separate; main01 remains5 valid,1 invalid/incomplete and12 unstarted. Main02's native results and final cleanup require their own raw audit. The auditor issued no native commands or mutations and did not launch main02.
