# C-01 independent raw pilot audit

Run: `20261115-c01-pilot-01`. Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor`.

**Main admission: PASS. Recommendation: CONTINUE to the separately frozen 18-trial main campaign.** The raw pilot supports **6 planned / 6 started / 6 completed / 6 valid / 0 invalid / 0 missing**. No native rerun or additional study arm is needed. The auditor has not launched main or issued native Docker calls.

## Independent evidence

The audit reconstructed gates from 535 driver/proxy events, 219 native-server events, 28 raw lifecycle request bodies, 24 upstream response bodies/metadata files, and 359 frozen trial observations. The four requests without upstream responses are the intentionally gated endpoint requests in the two known-ID trials. All 28 campaign checks and 114 per-trial checks passed; complete predicates, event line locators, packet paths, source checks, and raw-file hashes are in `PILOT_RAW_CHECKS.json`.

| Arm | Lifetime | SDK DELETE requests | First sample after terminal return | Verified scientific outcome |
| --- | --- | --- | --- | --- |
| normal | 60s | 1 | Absent | Native SDK removal completed before destroy returned. |
| known-ID cancellation | 60s | 1 | Absent | Native SDK removal completed before cancellation returned. |
| lost-ID cancellation | 60s | 0 | Allocated | Present beyond 30s; disappearance bracket 58.766–59.021s after cancellation returned, through the native expiry callback. |
| normal | manual | 1 | Absent | Native SDK removal completed before destroy returned. |
| known-ID cancellation | manual | 1 | Absent | Native SDK removal completed before cancellation returned. |
| lost-ID cancellation | manual | 0 | Allocated | Present at the last scientific sample, 30.150s after cancellation returned; right censored, then removed by separately logged administration. |

All six trials have exactly one SDK create POST, one upstream 202 containing an ID, one matching native target creation/start before that response, and a running object with the same ID and exact study/trial/role labels at injection. Frozen observation objects retain that target identity and declared CPU/memory/swap/PID limits. Trial admission intervals do not overlap.

Each of the four fault trials has one cancellation request against a pending SDK task, accepted cancellation, terminal `CancelledError`, and no administrative SDK cancellation. Both known-ID trials have two ID-bearing SDK endpoint requests before cancellation and one SDK DELETE. All four fault-arm independent readiness observations returned HTTP 200; normal controls record native SDK readiness success explicitly as their readiness source.

Both lost-ID trials capture the full upstream 202 before gating, record zero downstream create headers/body sent at the gate, observe downstream transport closure after SDK settlement, and release the single create response afterward. Neither has an SDK endpoint or DELETE request in the complete proxy/native HTTP ledger. Their separate SDK failure-telemetry bodies also omit a sandbox ID. Raw locators: `events.jsonl:94–111` and `:398–415`, with the latter range containing the manual lost-ID gate/settlement/release sequence.

## TTL, sentinel, and cleanup attribution

The finite lost-ID response expiry and Docker expiry label encode the same UTC instant. The native expiry callback enters at `server-events.jsonl:122`, approximately 0.0009s after the mapped expiry, and performs the target's kill/remove with actor `expiry_timer` at lines123–126 before callback exit at127. Native removal completion lies within the independently reconstructed presence/absence bracket. There is no SDK or administrative target deletion in this trial.

The manual lost-ID target has a manual-cleanup label, no response expiry, no expiry callback, no scientific-window absence, and a present sample after the declared 30s horizon. Administrative cleanup begins 30.734s after cancellation return (`events.jsonl:526`), obtains HTTP 204 at527, and its native target removal is tagged `admin` (`server-events.jsonl:215–219`). This is bounded retention followed by administration.

All **13** sentinel marker checks return exit code0 for the same running container identity: one initial check plus before/after each trial. The native lifecycle log has no kill/remove of that sentinel. It is removed only by final administration at `events.jsonl:535`, after native server termination at534. `UNSETTLED_AT_TEARDOWN.json` has no pending proxy create and no campaign failure. `FINAL_CLEANUP.json` records three consecutive empty owned inventories after shutdown and zero remaining owned IDs. Foreign container count is four before and after; logged native mutations address only the eight newly created target/sentinel/helper identities.

## Analysis correction and freeze integrity

The diff between preserved `reviews/analyze-v1.py` and current `analyze.py` changes exactly one line: create-response releases now require POST path `/sandboxes`. Each lost-ID trial contains one create-response release and one `/v1/metrics/events` release. The old selector counted both POSTs and falsely rejected `release_after_terminal`; the corrected selector matches the frozen native `TrialGate.creates` definition. Metrics requests, initial `ANALYSIS.json`, corrected `ANALYSIS-v2.json`, and both analysis versions remain available. Their embedded analysis hashes match their respective source files. No native record was rerun or removed to obtain six valid rows.

All four pilot protocol/driver hashes match current files. All **573** frozen upstream Python hashes match both current files and the pinned archive. The freeze timestamp precedes native server startup. All run-file hashes remained unchanged during this audit. The independent check compares timezone-aware expiry instants because response `Z` and Docker-label `+00:00` are equivalent; its initial literal-format check is retained in `PILOT_RAW_CHECKS-v1.json`.

The nominal sampler sleep is0.25s; actual full-trial median intervals are0.264–0.284s, with a maximum full-trial gap0.971s. Recomputed trial clock-pair disagreement is at most0.000023s, below the2s rule. Report actual observation brackets and the first post-return sample; avoid asserting fixed0.25s timing precision or exact instantaneous state between samples. Retained objects use terminal return+30s or finite expiry+15s as their deadline; the reviewed driver ends observation after confirmed absence.

## Main gate and claim

Freeze the corrected analysis source/hash alongside the existing native code/config/source/order, use the specified seed20261115 for three repetitions of all six cells, and keep pilot rows separate. Retain all incomplete/invalid main attempts and apply the existing stop rules. These are the already planned main-stage requirements.

The pilot establishes the intended local mechanism: accepted creation with an unobserved reply leaves the SDK without an ID-bearing cleanup request under cancellation, while finite server lifetime can remove the retained allocation independently. The manual-lifetime observation is right censored at its recorded horizon. Main will supply three repeat observations per cell; prevalence, permanent leaks, and broader backend behavior remain outside this experiment's scope.
