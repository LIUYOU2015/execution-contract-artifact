# C-01 independent implementation review

Reviewed 2026-11-15 by independent model auditor `c01_independent_auditor`. Audited inputs: `c01-lost-reply/src/{common,server,experiment}.py` and `tests/test_experiment.py`, with hashes in the companion JSON. This review concerns the pre-native implementation snapshot; later edits require a closeout check against these findings.

**Verdict: revise the five bounded items below before the native pilot. Recommendation: CONTINUE with those fixes.** The real SDK path, upstream response withholding, known-ID gate, one planned cancellation, and pre-initialization perimeter installation match the intended mechanism. Four existing mocked-Docker/loopback-HTTP tests independently passed. The fixes address measurement and cleanup validity; no new performance baseline or study arm is needed.

## Confirmed implementation properties

- `server.py:84–98` wraps the Docker factory and redirects the metadata constant before importing native `main`; the generated TOML redirects SQLite. The timer wrapper delegates the original method inside `try/finally`, records its actor, and preserves its returned value or exception.
- `server.py:64–66` replaces `raw.api` before returning native Docker models. Installed Docker model methods call `self.client.api.kill/remove_container`, so these models route through the wrapper. A post-construction model-binding bypass was not found for those operations.
- `experiment.py:37–40` gates SDK endpoint GETs in the known-ID arm. The SDK source assigns its ID before those calls. `experiment.py:42–54` fully reads the upstream create response and awaits the lost-ID gate before constructing the downstream `web.Response`.
- `experiment.py:119–132` verifies the fault gate while the SDK task remains pending, requires one upstream 202, verifies one running target, calls `task.cancel()` once in the scientific path, and waits with `asyncio.wait`. Administrative cancellation on an invalid/incomplete path is separately tagged.
- SDK headers identify actor/trial; observer/admin HTTP calls bypass the SDK proxy and carry separate actor headers (`experiment.py:59,75–94`). The observer's IDs are not supplied to the cancelled SDK task. Sentinel identity/running state and marker are checked around each trial.
- Configuration/order, source hashes, upstream Python hashes, and dependency snapshot are captured before server/sentinel creation (`experiment.py:175–183`). Healthy destroy and fault cancellation have separate timestamp fields.

## Required corrections

### I1 — Capture the cancellation interval and enforce the declared observation horizon

**Required for validity; high.** `experiment.py:134–151` starts its sampled observation list after SDK cancellation/destroy has returned. A healthy or known-ID DELETE can already have removed the target. In that case `last_present_ns` becomes null despite the earlier live injection observation; the claimed regular observation interval excludes the cleanup being compared. `lastpair=None` also skips the first observation interval and the upstream-202/gate/settlement interval for clock validation (`experiment.py:135–149`).

Start a continuous exact-target sampler before injection/cancellation, preserve the live injection observation, and keep it running while native SDK cleanup settles. Derive removal brackets from the last present sample before the first absence, with inspection start/end times retained. Check all relevant clock pairs from request/provisioning through settlement and observation, including the pair used to map `expiresAt` to monotonic time. Preserve unknown inspection failures and halt admissions as specified.

The current horizon is based on cancellation/destroy **request** (`anchor`) at `experiment.py:117,132,142`, while the protocol's at-return and later endpoints need an explicit anchor. Freeze that choice; to provide 30s follow-up after terminal cancellation, use at least `returned+30s` for a retained target. A target already confirmed absent can end earlier. Record the actual scientific horizon and competing TTL event.

### I2 — Verify cleanup after native provisioning can no longer create resources

**Required for validity and scoped cleanup; high.** `experiment.py:209–224` collects the final owned inventory before closing the proxy and terminating the native server. On a failed/slow create, SDK task cancellation does not stop the server's daemon provisioning thread (pinned `docker_service.py:681–714`). A target can therefore appear after the inventory written as `FINAL_CLEANUP.json`.

Track in-flight proxy/native creates and retain their incomplete status. Stop new admissions, resolve or explicitly mark outstanding create work, and perform the final exact-owned cleanup/inventory after server shutdown as well. Preserve actual accepted IDs and post-shutdown checks; a pre-shutdown empty inventory cannot establish zero remaining resources. Do not label an unknown outstanding create as clean. Test this path with a delayed mocked creator before native execution.

### I3 — Match ownership enforcement to the frozen perimeter

**Required for scoped cleanup; high.** `Scoped.check` (`server.py:68–71`) checks the study label alone. Creation permits any nonempty trial and does not validate role, registered immutable identity, or role-specific quota (`server.py:35–45`). Thus an SDK/target mutation against a same-study sentinel is allowed by the perimeter, and a total count of three permits multiple targets. Several unexpected operations, including image `pull`, pass through `API.__getattr__` (`server.py:28–30`). Native `_ensure_image_available` can call `images.pull` after an image/platform mismatch, even when a cached image exists (pinned `container_ops.py:243–276`).

Validate exact study/trial/role and registered container identity for mutations; reject target-path access to the sentinel. Enforce the declared one-target/one-sentinel/helper roles and quotas. Deny image pulls and other unused mutations, using the verified cached image platform explicitly if necessary. Log ownership refusals as stop events. Keep allowed Docker return values and errors intact. CPU tests should exercise same-study wrong-trial/role refusal and image-pull refusal, not only a mocked foreign-study refusal.

### I4 — Preserve observer errors as unknown

**Required for validity; medium.** `readiness()` catches every observer exception and returns `False` (`experiment.py:75–80`), then writes that boolean into `backend_ready` at line125. This turns an unavailable readiness observation into an observed negative and continues despite the protocol's observer-failure halt rule.

Return a structured observation with nullable readiness, status, and error. Keep valid non-ready responses distinct from unavailable measurements. Apply the declared observer-failure policy; an observer exception must remain visible in the per-trial record and validity accounting. The injection itself can establish a running Docker object independently of readiness.

### I5 — Record the downstream transport observation promised by the protocol

**Required for fault validation; medium.** The proxy logs generated flags `response_headers_sent=False`/`response_body_sent=False` before its gate (`experiment.py:50–51`); code structure supports those flags. It currently records no downstream disconnected/closing state when releasing the original response after SDK settlement, although protocol line23 requires that observation.

Log downstream transport state and request identity at gate entry and release, including a closing/closed observation after cancellation. Preserve response-write outcome when available. The existing loopback test proves that the HTTP client is cancelled before `proxy_response_released`; extend its assertion to the disconnect observation. Report absent SDK endpoint/DELETE requests from the complete SDK request ledger, with observer/admin events kept separate.

## Verification and next gate

The independent check used `env/bin/python -B -m unittest discover -s c01-lost-reply/tests -v`, with temporary writes redirected under `reviews/`. All four tests passed: foreign remove refusal, unlabeled create refusal, scoped label filter preservation, and withholding a full upstream response until client cancellation. Logs and tested hashes are in `IMPLEMENTATION_CPU_TESTS.txt` and `.json`. These tests establish their stated CPU/local-HTTP behavior; they do not exercise native Docker provisioning or the five corrections above.

No Docker command or native API call was issued by the auditor. All auditor writes are under `c01-lost-reply/reviews/`; upstream source remains untouched. After the five fixes and a short closeout, the six-arm pilot is the smallest useful next test. Native outcomes, valid/invalid denominators, TTL attribution, and final cleanup must then be independently checked before main campaign admission.
