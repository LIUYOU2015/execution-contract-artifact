# Offline selector correction before main

The first pilot analysis incorrectly counted every POST proxy-response release as a create response. Pinned SDK failure telemetry also POSTs to /v1/metrics/events, so both lost-ID rows falsely failed `release_after_terminal` because two POST releases were counted. Native `TrialGate.creates` already restricted POST /sandboxes and all native records are unchanged.

Correct analysis restricts create releases to POST paths ending /sandboxes, matching the frozen injection definition. Original ANALYSIS.json and analyze-v1.py are retained with their hashes. New result is ANALYSIS-v2.json; no native samples re-executed, excluded or overwritten. Metrics requests remain in the complete raw request ledger. This selector correction changes neither cancellation/TTL endpoints nor the prospective main design.
