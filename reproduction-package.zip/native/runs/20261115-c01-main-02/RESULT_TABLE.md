# C-01 native result table

Run `20261115-c01-main-02`: 18/18 valid, 0 invalid/incomplete started, 0 unstarted/missing planned.

| Path | Lifetime | n | SDK DELETE trials | Present beyond30s | TTL removal | Censored/admin |
|---|---|---:|---:|---:|---:|---:|
| normal | 60s | 3 | 3/3 | 0/3 | 0/3 | 0/3 / 0/3 |
| known_id_cancel | 60s | 3 | 3/3 | 0/3 | 0/3 | 0/3 / 0/3 |
| lost_id_cancel | 60s | 3 | 0/3 | 3/3 | 3/3 | 0/3 / 0/3 |
| normal | manual (None) | 3 | 3/3 | 0/3 | 0/3 | 0/3 / 0/3 |
| known_id_cancel | manual (None) | 3 | 3/3 | 0/3 | 0/3 | 0/3 / 0/3 |
| lost_id_cancel | manual (None) | 3 | 0/3 | 3/3 | 0/3 | 3/3 / 3/3 |

Observation offsets use SDK destroy return for normal controls and cancellation return for fault arms. Samples are bracketed by actual inspection times. Finite TTL starts before provisioning; manual retention is censored and administrative deletion is after the scientific horizon. Pilot/prior attempts are separate, not pooled.
