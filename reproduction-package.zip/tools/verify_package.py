"""Offline artifact verification. Stdlib only; never executes a native trial."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import sys

root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, 'File hash mismatch: '+name
cohort=json.loads((root/'literature/COHORT_54.json').read_text())
assert len(cohort['records'])==len({r['work_id'] for r in cohort['records']})==54
assert dict(collections.Counter(r['review_role'] for r in cohort['records']))=={'detailed':23,'context':28,'excluded':3}
source=json.loads((root/'literature/cohort.json').read_text())
for new,old in zip(cohort['records'],source['candidates']):
    assert all(new[k]==v for k,v in old.items()), old['work_id']
path=root/'native/code/c01-lost-reply/analyze.py'
spec=importlib.util.spec_from_file_location('original_c01_analysis',path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
run=root/'native/runs/20261115-c01-main-02'
observed=module.analyze(run)
saved=json.loads((run/'ANALYSIS.json').read_text())
assert observed==saved, 'Original native analysis differs from preserved output'
assert observed['valid']==observed['planned']==18 and observed['missing']==observed['invalid']==0
short=json.loads((root/'data/trials-18.json').read_text())['rows']
by_id={t['trial_id']:t for t in observed['trials']}
assert len(short)==len({t['trial_id'] for t in short})==18
mapping={'schedule':'arm','lifetime_s':'lifetime_s','valid':'valid','sdk_id_observed':'sdk_id_observed','sdk_delete_requests':'sdk_delete_requests','present_first_post_terminal':'retained_first_post_terminal','present_beyond_30s':'present_beyond_30s','natural_removal_bracket_s_after_terminal':'removal_bracket_after_terminal_s','right_censored':'right_censored','expiry_callback_entries':'expiry_callback_entries','expiry_remove_count':'expiry_remove_count','post_horizon_admin':'post_horizon_admin','terminal_latency_s':'terminal_latency_s'}
for t in short:
    assert all(t[a]==by_id[t['trial_id']][b] for a,b in mapping.items()),t['trial_id']
print(json.dumps({'status':'passed','files_hashed':len(manifest['files']),'candidate_counts':cohort['counts'],'native_main_analysis':'all fields reproduced from raw records','valid_trials':18,'missing_trials':0,'invalid_trials':0,'trial_preview_fields_verified':len(mapping)*18,'native_execution':False},indent=2))
